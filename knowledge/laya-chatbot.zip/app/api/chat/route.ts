import { OpenAIStream, StreamingTextResponse } from "ai"
import { createClient, testOpenRouterConnection, MODEL_CONFIG } from "@/lib/openrouter-client"
import { searchDocuments } from "@/lib/knowledge"

export const runtime = "nodejs"
export const maxDuration = 60 // 60 giây

export async function POST(req: Request) {
  try {
    console.log("API route handler started")

    // Kiểm tra API key
    const apiKey = process.env.OPENROUTER_API_KEY
    if (!apiKey) {
      console.error("OPENROUTER_API_KEY không được cấu hình")
      return new Response(
        JSON.stringify({ error: "API key không được cấu hình. Vui lòng kiểm tra biến môi trường." }),
        { status: 500, headers: { "Content-Type": "application/json" } },
      )
    }

    // Parse request body
    let messages
    try {
      const body = await req.json()
      messages = body.messages

      if (!messages || !Array.isArray(messages)) {
        console.error("Invalid request format: messages is missing or not an array")
        return new Response(
          JSON.stringify({ error: "Định dạng yêu cầu không hợp lệ. Thiếu trường messages hoặc không phải là mảng." }),
          { status: 400, headers: { "Content-Type": "application/json" } },
        )
      }

      console.log(`Received ${messages.length} messages`)
    } catch (error) {
      console.error("Error parsing request body:", error)
      return new Response(JSON.stringify({ error: "Không thể phân tích nội dung yêu cầu" }), {
        status: 400,
        headers: { "Content-Type": "application/json" },
      })
    }

    // Lấy tin nhắn cuối cùng
    const lastMessage = messages[messages.length - 1].content
    console.log("Last message:", lastMessage.substring(0, 100) + (lastMessage.length > 100 ? "..." : ""))

    // Tìm kiếm thông tin liên quan từ cơ sở kiến thức
    let relevantDocs = []
    try {
      relevantDocs = await searchDocuments(lastMessage)
      console.log(`Found ${relevantDocs.length} relevant documents`)
    } catch (error) {
      console.error("Error searching documents:", error)
      // Tiếp tục xử lý mà không có tài liệu liên quan
    }

    // Tạo context từ các tài liệu liên quan
    let context = ""
    if (relevantDocs.length > 0) {
      context = "Thông tin từ cơ sở kiến thức:\n\n" + relevantDocs.map((doc) => doc.content).join("\n\n")
    }

    // Tạo system prompt với context
    const systemPrompt = `Bạn là trợ lý AI của Laya, một hệ sinh thái trị liệu kết hợp Đông y, công nghệ và tâm trí học.
    
    ${context ? context : "Không tìm thấy thông tin liên quan trong cơ sở kiến thức."}
    
    Hãy trả lời câu hỏi dựa trên thông tin từ cơ sở kiến thức. Nếu không có thông tin, hãy nói rằng bạn không có thông tin về vấn đề đó và đề nghị người dùng liên hệ với Mentor Laya để được hỗ trợ.
    
    Trả lời bằng tiếng Việt, thân thiện và chuyên nghiệp. Sử dụng emoji 🌿 khi nói về sản phẩm Laya và ✨ khi nói về hệ thống Mentor.`

    // Kiểm tra kết nối với OpenRouter trước khi gửi yêu cầu chính
    try {
      console.log("Testing OpenRouter connection")
      const connectionTest = await testOpenRouterConnection()

      if (!connectionTest.success) {
        console.error("OpenRouter connection test failed:", connectionTest.message)
        return new Response(JSON.stringify({ error: `Không thể kết nối đến OpenRouter: ${connectionTest.message}` }), {
          status: 503,
          headers: { "Content-Type": "application/json" },
        })
      }

      console.log("OpenRouter connection test successful")
    } catch (error) {
      console.error("Error testing OpenRouter connection:", error)
      // Tiếp tục xử lý mặc dù kiểm tra kết nối thất bại
    }

    console.log("Creating OpenRouter client")
    const openai = createClient()

    // Tạo stream response
    try {
      console.log(`Creating chat completion with model: ${MODEL_CONFIG.modelId}`)
      const response = await openai.chat.completions.create({
        model: MODEL_CONFIG.modelId,
        messages: [{ role: "system", content: systemPrompt }, ...messages],
        stream: true,
        temperature: MODEL_CONFIG.temperature,
        max_tokens: MODEL_CONFIG.maxTokens,
      })

      console.log("Stream created successfully")

      // Trả về streaming response
      const stream = OpenAIStream(response)
      return new StreamingTextResponse(stream)
    } catch (error) {
      console.error("Error creating chat completion:", error)

      // Phân tích lỗi để cung cấp thông báo lỗi cụ thể
      let errorMessage = "Đã xảy ra lỗi khi xử lý yêu cầu. Vui lòng thử lại sau."
      let statusCode = 500

      if (error instanceof Error) {
        if (error.message.includes("API key")) {
          errorMessage = "API key không hợp lệ hoặc đã hết hạn."
          statusCode = 401
        } else if (error.message.includes("model")) {
          errorMessage = `Mô hình ${MODEL_CONFIG.modelId} không khả dụng hoặc không được hỗ trợ.`
          statusCode = 400
        } else if (error.message.includes("rate limit")) {
          errorMessage = "Đã vượt quá giới hạn tốc độ API. Vui lòng thử lại sau."
          statusCode = 429
        } else if (error.message.includes("timeout")) {
          errorMessage = "Yêu cầu đã hết thời gian chờ. Vui lòng thử lại sau."
          statusCode = 504
        }
      }

      // Thử phương án dự phòng - trả về phản hồi không streaming
      try {
        console.log("Attempting fallback to non-streaming response")

        // Tạo phản hồi không streaming
        const fallbackResponse = await openai.chat.completions.create({
          model: MODEL_CONFIG.modelId,
          messages: [{ role: "system", content: systemPrompt }, ...messages],
          stream: false,
          temperature: MODEL_CONFIG.temperature,
          max_tokens: MODEL_CONFIG.maxTokens / 2, // Giảm xuống để tránh timeout
        })

        const content = fallbackResponse.choices[0]?.message?.content || "Xin lỗi, tôi không thể trả lời ngay bây giờ."
        console.log("Fallback response generated successfully")

        return new Response(JSON.stringify({ text: content }), {
          headers: { "Content-Type": "application/json" },
        })
      } catch (fallbackError) {
        console.error("Fallback response also failed:", fallbackError)

        // Nếu cả hai phương án đều thất bại, trả về thông báo lỗi
        return new Response(
          JSON.stringify({
            error: errorMessage,
            details: error instanceof Error ? error.message : "Unknown error",
          }),
          {
            status: statusCode,
            headers: { "Content-Type": "application/json" },
          },
        )
      }
    }
  } catch (error) {
    console.error("Unhandled error in chat API:", error)
    return new Response(
      JSON.stringify({
        error: "Đã xảy ra lỗi không xác định khi xử lý yêu cầu",
        details: error instanceof Error ? error.message : "Unknown error",
      }),
      {
        status: 500,
        headers: { "Content-Type": "application/json" },
      },
    )
  }
}

// Thêm endpoint để kiểm tra trạng thái API
export async function GET() {
  try {
    const connectionTest = await testOpenRouterConnection()

    return new Response(
      JSON.stringify({
        status: connectionTest.success ? "ok" : "error",
        message: connectionTest.message,
        model: MODEL_CONFIG.modelId,
        timestamp: new Date().toISOString(),
      }),
      { headers: { "Content-Type": "application/json" } },
    )
  } catch (error) {
    return new Response(
      JSON.stringify({
        status: "error",
        message: "Không thể kiểm tra kết nối đến OpenRouter",
        details: error instanceof Error ? error.message : "Unknown error",
        timestamp: new Date().toISOString(),
      }),
      {
        status: 500,
        headers: { "Content-Type": "application/json" },
      },
    )
  }
}

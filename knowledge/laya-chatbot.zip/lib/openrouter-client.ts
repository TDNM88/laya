import OpenAI from "openai"

// Cấu hình mô hình và tham số
export const MODEL_CONFIG = {
  modelId: "meta-llama/llama-4-scout:free",
  temperature: 0.7,
  maxTokens: 1000,
  timeout: 55000, // 55 giây timeout
}

// Cập nhật hàm createOpenRouterClient với xử lý lỗi tốt hơn
export function createOpenRouterClient() {
  const apiKey = process.env.OPENROUTER_API_KEY

  if (!apiKey) {
    console.error("OPENROUTER_API_KEY không được cấu hình")
    throw new Error("OPENROUTER_API_KEY không được cấu hình")
  }

  return new OpenAI({
    baseURL: "https://openrouter.ai/api/v1",
    apiKey: apiKey,
    dangerouslyAllowBrowser: false, // Không cho phép chạy trong môi trường browser
    defaultHeaders: {
      "HTTP-Referer": "https://laya.company",
      "X-Title": "Laya Assistant",
    },
    defaultQuery: {
      timeout: MODEL_CONFIG.timeout,
    },
  })
}

// Thêm export createClient như một alias cho createOpenRouterClient
export const createClient = createOpenRouterClient

// Hàm trợ giúp để gửi tin nhắn đến OpenRouter với streaming
export async function sendChatCompletion(messages: any[], systemPrompt?: string) {
  // Thêm system prompt nếu có
  const formattedMessages = systemPrompt ? [{ role: "system", content: systemPrompt }, ...messages] : messages

  console.log(
    "Sending request to OpenRouter with messages:",
    JSON.stringify(
      formattedMessages.map((m) => ({
        role: m.role,
        content: typeof m.content === "string" ? m.content.substring(0, 50) + "..." : "[Complex content]",
      })),
    ),
  )

  const openai = createOpenRouterClient()

  try {
    return await openai.chat.completions.create({
      model: MODEL_CONFIG.modelId,
      messages: formattedMessages,
      temperature: MODEL_CONFIG.temperature,
      max_tokens: MODEL_CONFIG.maxTokens,
      stream: true,
    })
  } catch (error) {
    console.error("Error in sendChatCompletion:", error)
    throw error
  }
}

// Hàm trợ giúp để gửi tin nhắn không streaming
export async function sendChatCompletionNonStreaming(messages: any[], systemPrompt?: string) {
  // Thêm system prompt nếu có
  const formattedMessages = systemPrompt ? [{ role: "system", content: systemPrompt }, ...messages] : messages

  console.log("Sending non-streaming request to OpenRouter")

  const openai = createOpenRouterClient()

  try {
    const completion = await openai.chat.completions.create({
      model: MODEL_CONFIG.modelId,
      messages: formattedMessages,
      temperature: MODEL_CONFIG.temperature,
      max_tokens: MODEL_CONFIG.maxTokens,
      stream: false,
    })

    return completion.choices[0].message.content || ""
  } catch (error) {
    console.error("Error in sendChatCompletionNonStreaming:", error)
    throw error
  }
}

// Hàm kiểm tra kết nối với OpenRouter
export async function testOpenRouterConnection(): Promise<{ success: boolean; message: string }> {
  try {
    const openai = createOpenRouterClient()

    // Gửi một yêu cầu đơn giản để kiểm tra kết nối
    const response = await openai.chat.completions.create({
      model: MODEL_CONFIG.modelId,
      messages: [{ role: "user", content: "Hello" }],
      max_tokens: 5,
      stream: false,
    })

    return {
      success: true,
      message: `Kết nối thành công với OpenRouter. Mô hình ${MODEL_CONFIG.modelId} hoạt động bình thường.`,
    }
  } catch (error) {
    console.error("Error testing OpenRouter connection:", error)

    let errorMessage = "Không thể kết nối đến OpenRouter."

    if (error instanceof Error) {
      if (error.message.includes("API key")) {
        errorMessage = "API key không hợp lệ hoặc đã hết hạn."
      } else if (error.message.includes("model")) {
        errorMessage = `Mô hình ${MODEL_CONFIG.modelId} không khả dụng hoặc không được hỗ trợ.`
      } else if (error.message.includes("rate limit")) {
        errorMessage = "Đã vượt quá giới hạn tốc độ API. Vui lòng thử lại sau."
      }
    }

    return {
      success: false,
      message: errorMessage,
    }
  }
}
